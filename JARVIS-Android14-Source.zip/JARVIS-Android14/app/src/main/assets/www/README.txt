J.A.R.V.I.S. app - setup

1. Host these files over HTTPS (Netlify Drop, GitHub Pages, Cloudflare Pages). Camera, microphone and Google sign-in do not work from a plain file.
2. Open the site on your phone and use "Add to Home Screen".

Google sign-in (Gmail + Calendar)
1. Go to console.cloud.google.com and create a project.
2. Enable "Gmail API" and "Google Calendar API".
3. Credentials > Create credentials > OAuth client ID > Web application.
4. Add your site address under "Authorized JavaScript origins".
5. In the app: Settings (top right) > paste the Client ID > Sign in with Google.

Face lock
Settings > Enroll face (camera must be allowed). Turn on "Require my face" to lock Gmail and Calendar until your face is recognised. Face data stays in this browser only.

Laptop link
On your laptop open laptop.html from the same site. In the app: Settings > Scan laptop QR. The laptop shows 'Phone connected' and the app shows 'Laptop connected and working'. Use Test on either side to re-check.

Voice language
English / Hindi / Marathi buttons under the orb, or in Settings.

NEW: Brain, code and images
Brain: menu (three lines, top left) > Extra options > Brain. Pick Gemini (free key from aistudio.google.com > Get API key) or Claude (key from console.anthropic.com), paste the key. It stays in your browser only.
Code: menu > Code. Describe what you want, tap Write code, then Run (web code) or Copy. You can also just ask Jarvis to write code in the chat.
Images: say or type "create an image of ..." and Jarvis draws it (free service, may be slow or busy, tap the image to open it full size).
Camera motion: menu > Camera motion.

Laptop guard: after pairing, tap Start guarding on the laptop page. Your phone is alerted if the laptop moves (location or motion sensor), is unplugged, or goes offline. Keep both pages open.

Alerts when Jarvis is closed: Extra options > Notifications > turn on "Alert me when Jarvis is closed". Install the free ntfy app on your phone and subscribe to the topic shown. Pair the laptop once (scan QR) so it learns the topic.

NEW: Memory, uploads and incognito
Memory: Jarvis now keeps your past chats on this device (menu > Chat history) and uses them in its answers. Say "remember that ..." to save a fact, "forget that ..." to remove it. It also notes your name and where you live if you say them. See, add or delete facts under menu > Memory. Memory can be turned off there, and "Delete all chat history and memory" wipes everything. Chats are stored only in this browser (IndexedDB); clearing the site's data removes them.
Uploads: tap the + button in the message box and choose Image, Video or File. You can also paste or drag files in on a computer. Images are shrunk on your device first. Video is sent as a handful of frames (Gemini also receives the full clip when it is under 12 MB). Text, code, CSV and JSON files are read directly. PDFs need the Gemini or Claude brain; the free brain cannot read PDFs and is best-effort with images. Up to 8 items per message.
Incognito: tap the hat-and-glasses icon at the top right. The chat is never saved, Jarvis does not read or write memory, and everything is erased when you leave incognito. Your chosen AI service (free service, Gemini or Claude) still receives the messages you send, as in any chat.
