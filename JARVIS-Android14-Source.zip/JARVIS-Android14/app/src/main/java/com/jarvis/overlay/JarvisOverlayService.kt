package com.jarvis.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class JarvisOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var expanded = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var status: TextView? = null
    private val channel = "jarvis_overlay_channel"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("J.A.R.V.I.S. is active")
            .setContentText("Floating notch and wake-word listening are running. Tap to return to Jarvis.")
            .setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(41, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPill()
        beginListening()
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channel, "JARVIS floating assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
    private fun bg(radius: Float): GradientDrawable = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = radius; setStroke(1, 0xFF343434.toInt()) }
    private fun showPill() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = bg(80f); setPadding(20, 9, 20, 9) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val dot = TextView(this).apply { text = "●"; textSize = 10f; setTextColor(0xFFFF9A2E.toInt()); setPadding(0,0,9,0) }
        val label = TextView(this).apply { text = "JARVIS"; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = .12f }
        row.addView(dot); row.addView(label); root.addView(row)
        status = TextView(this).apply { text = "Listening for ‘Hey Jarvis’"; setTextColor(0xFFFFB86B.toInt()); textSize = 11f; gravity = Gravity.CENTER; visibility = android.view.View.GONE; setPadding(0,8,0,0) }
        root.addView(status)
        root.setOnClickListener { toggleExpanded() }
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
        panel = root
        try { wm.addView(root, params) } catch (_: Exception) {}
    }
    private fun toggleExpanded() {
        expanded = !expanded
        status?.visibility = if (expanded) android.view.View.VISIBLE else android.view.View.GONE
        status?.text = if (expanded) "Listening • Say ‘Hey Jarvis’" else "Listening for ‘Hey Jarvis’"
        if (expanded) status?.setOnClickListener {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("showAssistant", true)
            startActivity(i)
        }
    }
    private fun wake() {
        expanded = true
        status?.visibility = android.view.View.VISIBLE
        status?.text = "HEY JARVIS DETECTED  •  TAP TO OPEN"
        status?.setOnClickListener {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("showAssistant", true)
            startActivity(i)
        }
    }
    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status?.text = "Speech recognition unavailable"; return }
        try { recognizer = SpeechRecognizer.createSpeechRecognizer(this) } catch (_: Exception) { return }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false; restartSoon() }
            override fun onError(error: Int) { listening = false; restartSoon() }
            override fun onResults(results: android.os.Bundle?) { inspect(results); listening = false; restartSoon() }
            override fun onPartialResults(partialResults: android.os.Bundle?) { inspect(partialResults) }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        startRecognition()
    }
    private fun inspect(bundle: android.os.Bundle?) {
        val matches = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (matches.any { it.lowercase(Locale.ROOT).contains("hey jarvis") || it.lowercase(Locale.ROOT).contains("hey j.a.r.v.i.s") }) wake()
    }
    private fun startRecognition() {
        if (recognizer == null || listening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        try { recognizer?.startListening(intent); listening = true } catch (_: Exception) { listening = false }
    }
    private fun restartSoon() { android.os.Handler(mainLooper).postDelayed({ if (panel != null && !listening) startRecognition() }, 900) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
