package com.jarvis.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.content.pm.PackageManager
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private val req = 410
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val title = TextView(this).apply { text = "J.A.R.V.I.S.  •  ANDROID NOTCH"; setTextColor(0xFFFFA13A.toInt()); textSize = 16f; gravity = Gravity.CENTER; setPadding(12,18,12,18) }
        val info = TextView(this).apply { text = "Grant overlay and microphone permissions, then start the floating notch. Keep its notification active for background operation."; setTextColor(Color.WHITE); textSize = 14f; setPadding(18,8,18,12) }
        val grant = Button(this).apply { text = "Grant display-over-other-apps permission"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } }
        val start = Button(this).apply { text = "START JARVIS NOTCH + WAKE LISTENING"; setOnClickListener { startJarvis() } }
        val open = Button(this).apply { text = "OPEN JARVIS ASSISTANT"; setOnClickListener { showAssistant(root) } }
        root.addView(title); root.addView(info); root.addView(grant); root.addView(start); root.addView(open)
        setContentView(root)
        if (intent.getBooleanExtra("showAssistant", false)) showAssistant(root)
    }
    private fun startJarvis() {
        if (!Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), req); return }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), req + 1)
        val i = Intent(this, JarvisOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == req && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startJarvis()
    }
    private fun showAssistant(root: LinearLayout) {
        root.removeAllViews()
        val web = WebView(this)
        web.settings.javaScriptEnabled = true; web.settings.domStorageEnabled = true; web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val audioGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE && audioGranted }.toTypedArray()
                    if (allowed.isNotEmpty()) request.grant(allowed) else request.deny()
                }
            }
        }; web.webViewClient = WebViewClient()
        web.settings.allowFileAccess = true; web.settings.allowContentAccess = true
        web.loadUrl("file:///android_asset/www/index.html")
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    }
}
