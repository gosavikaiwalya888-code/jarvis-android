J.A.R.V.I.S. ANDROID 14 FLOATING NOTCH — SOURCE PROJECT

This is a native Android Studio project. It adds a black floating pill overlay that can remain above other apps while its foreground service is running. Tap the pill to expand it; tap the expanded status line to open the bundled original Jarvis web assistant.

INSTALL / BUILD
1. Install Android Studio (Hedgehog or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated app-debug.apk on your Android 14 phone.
5. Open J.A.R.V.I.S.; grant Display over other apps and Microphone permissions.
6. Tap START JARVIS NOTCH + WAKE LISTENING. Keep the ongoing JARVIS notification active.
7. The pill floats over other apps. Say “Hey Jarvis”; the pill expands. Tap its expanded status to open the assistant.

IMPORTANT ANDROID 14 NOTES
- Android requires the user to grant overlay permission and microphone permission.
- Microphone foreground service must be started while the app is visible. Do not swipe away/force-stop the app if you want the service to continue.
- SpeechRecognizer is platform/provider dependent and is not a guaranteed always-on hotword engine. It may stop due to battery optimization, vendor restrictions, network, or speech-service behaviour. For robust low-power offline hotword detection, integrate a dedicated wake-word engine and model.
- The floating overlay can appear above other apps only while Android allows the overlay permission and the service remains active. Some secure/system screens may block overlays.
- This is a source project, not a precompiled APK. Build it in Android Studio.

The original JARVIS website and its libraries are bundled under app/src/main/assets/www.
